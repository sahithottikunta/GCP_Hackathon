"""
SENTINEL — Synthetic Market Data Stream
Generates realistic tick-level market data with anomaly injection.
Feeds the ML pipeline and broadcasts to connected clients.
"""

from __future__ import annotations
import asyncio
import time
import math
import random
from typing import Optional, Callable, Awaitable
from collections import deque
from models.anomaly_detector import AnomalyDetectorML
from utils import get_logger

log = get_logger("data_stream")


class MarketDataStream:
    """
    Generates synthetic market data with realistic properties:
    - Geometric Brownian Motion base price
    - Mean-reverting volatility (GARCH-like)
    - Clustered volume with regime shifts
    - Injected anomalies (spikes, dislocations, spoofing patterns)
    """

    def __init__(self):
        self.price = 142.50
        self.volume = 2_500_000
        self.volatility = 0.015
        self.base_volatility = 0.015
        self.tick_count = 0
        self.running = False
        self.detector = AnomalyDetectorML()
        self.price_history: deque = deque(maxlen=2000)
        self.anomaly_history: deque = deque(maxlen=500)
        self._callbacks: list[Callable] = []
        self._anomaly_callbacks: list[Callable] = []

    def on_tick(self, callback: Callable[[dict], Awaitable]):
        """Register a callback for each new tick."""
        self._callbacks.append(callback)

    def on_anomaly(self, callback: Callable[[dict], Awaitable]):
        """Register a callback for detected anomalies."""
        self._anomaly_callbacks.append(callback)

    def _generate_tick(self) -> dict:
        """Generate a single synthetic market tick."""
        self.tick_count += 1
        now = time.time()

        # ── Volatility dynamics (mean-reverting) ──
        self.volatility += 0.1 * (self.base_volatility - self.volatility) + random.gauss(0, 0.002)
        self.volatility = max(0.005, min(0.08, self.volatility))

        # ── Anomaly injection (5% chance) ──
        shock = 0.0
        vol_shock = 1.0
        if random.random() < 0.05:
            shock = random.choice([-1, 1]) * random.uniform(2, 8)
            vol_shock = random.uniform(2.0, 5.0)

        # ── Price (GBM + shocks) ──
        drift = 0.0001 * math.sin(self.tick_count / 200)  # subtle trend
        noise = random.gauss(0, 1) * self.volatility * self.price
        self.price = max(50, self.price + drift * self.price + noise + shock)

        # ── Volume ──
        base_vol = self.volume * (0.85 + random.random() * 0.3)
        self.volume = int(max(200_000, base_vol * vol_shock))

        # ── OHLC ──
        high = self.price + abs(random.gauss(0, 1)) * self.volatility * self.price
        low = self.price - abs(random.gauss(0, 1)) * self.volatility * self.price
        opn = self.price + random.gauss(0, 0.5)

        tick = {
            "timestamp": now,
            "symbol": "SYNTH",
            "price": round(self.price, 2),
            "open": round(opn, 2),
            "high": round(high, 2),
            "low": round(low, 2),
            "volume": self.volume,
            "volatility": round(self.volatility * 100, 3),
            "tick_number": self.tick_count,
        }

        self.price_history.append(tick)
        return tick

    async def start(self, interval_ms: int = 500):
        """Start the data stream loop."""
        self.running = True
        log.info(f"Market data stream started (interval={interval_ms}ms)")

        while self.running:
            tick = self._generate_tick()

            # ── ML scoring ──
            ml_result = self.detector.process_tick(
                tick["price"], tick["volume"], tick["timestamp"]
            )
            tick["anomaly_score"] = ml_result["ensemble_score"]
            tick["is_anomaly"] = ml_result["is_anomaly"]
            tick["anomaly_type"] = ml_result["primary_type"]
            tick["severity"] = ml_result["severity"]
            tick["model_scores"] = {
                k: v["score"] for k, v in ml_result["models"].items()
            }

            # ── Notify tick callbacks ──
            for cb in self._callbacks:
                try:
                    await cb(tick)
                except Exception as e:
                    log.error(f"Tick callback error: {e}")

            # ── Notify anomaly callbacks ──
            if ml_result["is_anomaly"]:
                self.anomaly_history.append(ml_result)
                for cb in self._anomaly_callbacks:
                    try:
                        await cb(ml_result)
                    except Exception as e:
                        log.error(f"Anomaly callback error: {e}")

            await asyncio.sleep(interval_ms / 1000.0)

    def stop(self):
        """Stop the data stream."""
        self.running = False
        log.info("Market data stream stopped")

    def get_snapshot(self) -> dict:
        """Current market state for agent context."""
        if not self.price_history:
            return {"status": "no_data"}

        recent = list(self.price_history)[-50:]
        prices = [t["price"] for t in recent]
        volumes = [t["volume"] for t in recent]

        return {
            "current_price": recent[-1]["price"],
            "current_volume": recent[-1]["volume"],
            "price_range_50": {"min": round(min(prices), 2), "max": round(max(prices), 2)},
            "avg_volume_50": int(sum(volumes) / len(volumes)),
            "current_volatility": recent[-1]["volatility"],
            "total_ticks": self.tick_count,
            "recent_anomalies": len([a for a in list(self.anomaly_history)[-20:]]),
            "ml_summary": self.detector.get_summary(),
        }


# Singleton
market_stream = MarketDataStream()
