"""
SENTINEL — LLM Service
Unified interface to Anthropic Claude (reasoning) and OpenAI (vision/audio).
Supports streaming responses for real-time delivery.
"""

from __future__ import annotations
import asyncio
import base64
from typing import AsyncGenerator, Optional, List, Dict
from config import settings
from utils import get_logger

log = get_logger("llm")

# ── System Prompts ────────────────────────────────────

FINANCIAL_ANALYST_SYSTEM = """You are SENTINEL, an elite real-time financial analyst AI voice agent.

ROLE: Senior quantitative analyst + compliance investigator at a top-tier hedge fund.

VOICE STYLE:
- Speak naturally as if talking to a colleague on a trading floor
- Be concise but thorough — every word should add value
- Use phrases like "What stands out here is...", "This is atypical because...", "If we look at the data..."
- Maintain a calm, authoritative, confident tone
- Keep responses to 2-4 sentences for simple queries, up to a short paragraph for complex analysis

CAPABILITIES:
- Analyze real-time market data, price action, volume patterns
- Detect and explain anomalies (spoofing, wash trades, unusual flow)
- Interpret charts and visual data when images are provided
- Reason step-by-step through complex market scenarios
- Assess correlation shifts, volatility regimes, risk factors

RULES:
- Never hallucinate specific numbers unless provided in context
- State uncertainty explicitly when data is incomplete
- Never provide trading advice or specific trade recommendations
- Focus on analysis, interpretation, and risk awareness
- If interrupted, gracefully acknowledge and pivot

When given market context data, incorporate it naturally into your spoken response."""

VISION_ANALYST_SYSTEM = """You are SENTINEL's vision module — a financial chart analysis expert.
When shown an image of a chart, trading screen, or financial data:
1. Describe what you see concisely
2. Identify key patterns (support/resistance, trend lines, volume patterns)
3. Flag anything anomalous or noteworthy
4. Speak as if narrating to a colleague looking at the same screen
Keep it to 3-5 sentences unless asked for more detail."""


class LLMService:
    """Unified LLM interface supporting Claude + OpenAI."""

    def __init__(self):
        self._anthropic = None
        self._openai = None
        self._init_clients()

    def _init_clients(self):
        if settings.has_anthropic:
            try:
                import anthropic
                self._anthropic = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
                log.info("Anthropic client initialized")
            except Exception as e:
                log.warning(f"Anthropic init failed: {e}")

        if settings.has_openai:
            try:
                import openai
                self._openai = openai.AsyncOpenAI(api_key=settings.openai_api_key)
                log.info("OpenAI client initialized")
            except Exception as e:
                log.warning(f"OpenAI init failed: {e}")

        if not self._anthropic and not self._openai:
            log.warning("No LLM API keys configured — using mock responses")

    # ── Text Generation (Claude Primary) ──────────────

    async def generate(
        self,
        user_message: str,
        conversation_history: List[Dict[str, str]] = None,
        system_prompt: str = FINANCIAL_ANALYST_SYSTEM,
        market_context: dict = None,
    ) -> str:
        """Generate a text response using Claude (preferred) or OpenAI fallback."""

        # Inject market context
        augmented_system = system_prompt
        if market_context:
            augmented_system += f"\n\nCURRENT MARKET CONTEXT:\n{_format_context(market_context)}"

        messages = []
        if conversation_history:
            messages.extend(conversation_history)
        messages.append({"role": "user", "content": user_message})

        # Try Anthropic first
        if self._anthropic:
            try:
                resp = await self._anthropic.messages.create(
                    model=settings.anthropic_model,
                    max_tokens=1024,
                    system=augmented_system,
                    messages=messages,
                )
                return resp.content[0].text
            except Exception as e:
                log.error(f"Anthropic error: {e}")

        # OpenAI fallback
        if self._openai:
            try:
                oai_messages = [{"role": "system", "content": augmented_system}] + messages
                resp = await self._openai.chat.completions.create(
                    model="gpt-4o",
                    messages=oai_messages,
                    max_tokens=1024,
                )
                return resp.choices[0].message.content
            except Exception as e:
                log.error(f"OpenAI error: {e}")

        return _mock_response(user_message)

    # ── Streaming Generation ──────────────────────────

    async def generate_stream(
        self,
        user_message: str,
        conversation_history: List[Dict[str, str]] = None,
        system_prompt: str = FINANCIAL_ANALYST_SYSTEM,
        market_context: dict = None,
    ) -> AsyncGenerator[str, None]:
        """Stream text response token-by-token for real-time TTS."""

        augmented_system = system_prompt
        if market_context:
            augmented_system += f"\n\nCURRENT MARKET CONTEXT:\n{_format_context(market_context)}"

        messages = []
        if conversation_history:
            messages.extend(conversation_history)
        messages.append({"role": "user", "content": user_message})

        if self._anthropic:
            try:
                async with self._anthropic.messages.stream(
                    model=settings.anthropic_model,
                    max_tokens=1024,
                    system=augmented_system,
                    messages=messages,
                ) as stream:
                    async for text in stream.text_stream:
                        yield text
                return
            except Exception as e:
                log.error(f"Anthropic stream error: {e}")

        if self._openai:
            try:
                oai_messages = [{"role": "system", "content": augmented_system}] + messages
                stream = await self._openai.chat.completions.create(
                    model="gpt-4o",
                    messages=oai_messages,
                    max_tokens=1024,
                    stream=True,
                )
                async for chunk in stream:
                    delta = chunk.choices[0].delta.content
                    if delta:
                        yield delta
                return
            except Exception as e:
                log.error(f"OpenAI stream error: {e}")

        # Mock fallback
        for word in _mock_response(user_message).split():
            yield word + " "
            await asyncio.sleep(0.05)

    # ── Vision Analysis ───────────────────────────────

    async def analyze_image(
        self,
        image_base64: str,
        query: str = "Analyze this financial chart and describe what you see.",
        media_type: str = "image/png",
    ) -> str:
        """Analyze a chart/image using vision-capable models."""

        # Try Anthropic Claude Vision
        if self._anthropic:
            try:
                resp = await self._anthropic.messages.create(
                    model=settings.anthropic_model,
                    max_tokens=1024,
                    system=VISION_ANALYST_SYSTEM,
                    messages=[{
                        "role": "user",
                        "content": [
                            {"type": "image", "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": image_base64,
                            }},
                            {"type": "text", "text": query},
                        ],
                    }],
                )
                return resp.content[0].text
            except Exception as e:
                log.error(f"Anthropic vision error: {e}")

        # OpenAI GPT-4o Vision fallback
        if self._openai:
            try:
                resp = await self._openai.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": VISION_ANALYST_SYSTEM},
                        {"role": "user", "content": [
                            {"type": "image_url", "image_url": {
                                "url": f"data:{media_type};base64,{image_base64}",
                            }},
                            {"type": "text", "text": query},
                        ]},
                    ],
                    max_tokens=1024,
                )
                return resp.choices[0].message.content
            except Exception as e:
                log.error(f"OpenAI vision error: {e}")

        return "Vision analysis unavailable — no vision-capable API configured."

    # ── Speech to Text ────────────────────────────────

    async def transcribe_audio(self, audio_bytes: bytes, format: str = "wav") -> str:
        """Transcribe audio using Whisper."""
        if self._openai:
            try:
                import io
                audio_file = io.BytesIO(audio_bytes)
                audio_file.name = f"audio.{format}"
                transcript = await self._openai.audio.transcriptions.create(
                    model=settings.openai_stt_model,
                    file=audio_file,
                    response_format="text",
                )
                return transcript.strip()
            except Exception as e:
                log.error(f"Whisper STT error: {e}")
                return ""
        log.warning("No STT service available")
        return ""

    # ── Text to Speech ────────────────────────────────

    async def synthesize_speech(self, text: str) -> Optional[bytes]:
        """Convert text to speech audio bytes."""
        if self._openai:
            try:
                response = await self._openai.audio.speech.create(
                    model=settings.openai_tts_model,
                    voice=settings.openai_tts_voice,
                    input=text,
                    response_format="mp3",
                )
                return response.content
            except Exception as e:
                log.error(f"TTS error: {e}")
                return None
        log.warning("No TTS service available")
        return None

    async def synthesize_speech_stream(self, text: str) -> AsyncGenerator[bytes, None]:
        """Stream TTS audio in chunks for low-latency playback."""
        if self._openai:
            try:
                response = await self._openai.audio.speech.create(
                    model=settings.openai_tts_model,
                    voice=settings.openai_tts_voice,
                    input=text,
                    response_format="mp3",
                )
                # Chunk the audio for streaming
                audio = response.content
                chunk_size = 4096
                for i in range(0, len(audio), chunk_size):
                    yield audio[i:i + chunk_size]
            except Exception as e:
                log.error(f"TTS stream error: {e}")


def _format_context(ctx: dict) -> str:
    """Format market context dict into readable text for the LLM."""
    lines = []
    for key, val in ctx.items():
        if isinstance(val, dict):
            lines.append(f"  {key}:")
            for k2, v2 in val.items():
                lines.append(f"    {k2}: {v2}")
        else:
            lines.append(f"  {key}: {val}")
    return "\n".join(lines)


def _mock_response(query: str) -> str:
    """Fallback mock response when no LLM is configured."""
    return (
        f"I'm analyzing your query about '{query[:50]}'. "
        "In a production environment, this would route through Claude or GPT-4o "
        "for real-time financial analysis. The ML anomaly detection pipeline is "
        "still running and scoring market data — you'd see those results on the dashboard. "
        "To enable full voice analysis, configure your API keys in the .env file."
    )


# Singleton
llm_service = LLMService()
